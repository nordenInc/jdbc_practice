create procedure ArtworksCount(OUT cnt int)
  BEGIN
    select count(*) into cnt from artworks;
  END;

