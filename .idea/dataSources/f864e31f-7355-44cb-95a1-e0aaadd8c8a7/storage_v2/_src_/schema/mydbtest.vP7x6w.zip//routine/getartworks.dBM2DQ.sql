create procedure getArtworks(IN artworkId int)
  BEGIN
    select * from artworks where id = artworkId;
  END;

