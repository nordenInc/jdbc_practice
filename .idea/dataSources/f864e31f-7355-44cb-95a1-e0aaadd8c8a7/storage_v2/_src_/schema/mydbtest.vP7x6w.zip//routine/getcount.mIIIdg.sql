create procedure getCount()
  BEGIN
    select count(*) from user;
    select count(*) from artworks;
  END;

